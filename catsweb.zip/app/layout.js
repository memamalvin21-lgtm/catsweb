
export const metadata = { title: 'CatsWeb' };
export default function RootLayout({ children }) {
  return <html><body>{children}</body></html>;
}
