
import Image from 'next/image';

export default function Home() {
  return (
    <main style={{padding:'40px',fontFamily:'Arial'}}>
      <h1>CatsWeb 🐱</h1>
      <p>Welcome to CatsWeb, a simple cat gallery.</p>
      <div style={{display:'grid',gap:'20px'}}>
        <Image src="/image(2).png" alt="Cat" width={500} height={500} />
        <Image src="/image(3).png" alt="Cat" width={500} height={500} />
      </div>
    </main>
  );
}
